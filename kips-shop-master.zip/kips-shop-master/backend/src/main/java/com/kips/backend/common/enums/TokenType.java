package com.kips.backend.common.enums;

public enum TokenType {
    BEARER
}
