package com.kips.backend.service;

public interface EmailService {
    void send(String to, String email);
}
